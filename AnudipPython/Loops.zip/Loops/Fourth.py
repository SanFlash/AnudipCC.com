for i in range(1, 6):
    for j in range(i):
        print(chr(65 + j), end=" ")
    print()
