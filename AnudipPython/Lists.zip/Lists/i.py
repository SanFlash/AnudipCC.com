numbers = list(range(1, 11))
slist = numbers[2:8]
print(slist)
numbers.insert(5, 99)

print(numbers)
