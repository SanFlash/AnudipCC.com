my_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
slist = my_list[1:4]
print(slist)
my_list[3] = 'x'
my_list.remove('g')
my_list.append('z')

print(my_list)
