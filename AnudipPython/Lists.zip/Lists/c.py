num = [1, 2, 3, 4, 5, 6, 7, 8, 9]
print(num[:5])
print(num[1::2])
print(num[::-1])
