fruit = ['apple', 'banana', 'cherry', 'date', 'elderberry']
print(fruit[1], fruit[3])
fruit[2] = 'citrus'
print(fruit)
