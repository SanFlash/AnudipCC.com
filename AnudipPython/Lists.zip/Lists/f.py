elist = []
for i in range(5, 0, -1):
    elist.insert(0, i)

elist.insert(2, 'middle')

print(elist)
