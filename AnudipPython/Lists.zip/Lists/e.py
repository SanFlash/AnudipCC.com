colors = ['red', 'blue', 'green']
colors.insert(1, 'yellow')
colors.append('purple')
colors.insert(0, 'orange')

print(colors)
