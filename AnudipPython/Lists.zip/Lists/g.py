nums = [10, 20, 30, 40, 50, 60]
nums.clear()

print(nums)
