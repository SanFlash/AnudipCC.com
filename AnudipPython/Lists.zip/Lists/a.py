my_list = [10, 20, 30, 40, 50]
print(my_list[0])
print(my_list[-1])
print(my_list[2])
