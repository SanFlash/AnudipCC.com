a = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
print(a[:5])
print(a[-5:])
print(a[::2])
